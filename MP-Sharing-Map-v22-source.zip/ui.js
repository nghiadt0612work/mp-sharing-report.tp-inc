const settingsButton=$('#settingsButton'),settingsMenu=$('#settingsMenu');
function closeSettings(){settingsMenu.hidden=true;settingsButton.setAttribute('aria-expanded','false')}
function toggleSettings(event){event.preventDefault();event.stopPropagation();const willOpen=settingsMenu.hidden;settingsMenu.hidden=!willOpen;settingsButton.setAttribute('aria-expanded',String(willOpen))}
settingsButton.addEventListener('click',toggleSettings);
settingsMenu.addEventListener('click',event=>event.stopPropagation());
document.querySelector('.languages').addEventListener('click',event=>{if(event.target.closest('[data-lang]'))closeSettings()});
document.addEventListener('click',event=>{if(!event.target.closest('.settings'))closeSettings()});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeSettings()});

let theme=document.documentElement.dataset.theme||'light';
function applyTheme(value){theme=value;document.documentElement.dataset.theme=value;document.querySelectorAll('[data-theme-value]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.themeValue===value)));try{localStorage.setItem('tp-theme',value)}catch{}}
document.querySelector('.theme-options').addEventListener('click',event=>{const button=event.target.closest('[data-theme-value]');if(!button)return;applyTheme(button.dataset.themeValue);closeSettings()});
applyTheme(theme);
