const originalDirectory=window.DIRECTORY||[];
try{document.documentElement.dataset.theme=localStorage.getItem('tp-theme')||'light'}catch{document.documentElement.dataset.theme='light'}
const aiReports=[
 {title:'Factories Eff% Preview',url:'https://factories-eff-preview-2026.nghiaraver97.chatgpt.site/',folder:false},
 {title:'Style Completion Report',url:'https://qme-style-completion-report.nghiaraver97.chatgpt.site/',folder:false}
];
window.DIRECTORY=originalDirectory.slice(0,4).map((group,index)=>{
 const title=index===3?'AI Report':group.title.replace(/^\d+\.\s*/,'');
 return {...group,title:String(index+1).padStart(2,'0')+'. '+title,children:index===3?aiReports:group.children,url:index===3?'':group.url};
});
